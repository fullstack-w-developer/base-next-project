declare module "persian-number";
declare module "react-input-emoji";
declare module "uuid";
declare module "serialize";
