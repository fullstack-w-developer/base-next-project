import fetchClient from "../fetchClient";

interface Props {
    id: string;
}
