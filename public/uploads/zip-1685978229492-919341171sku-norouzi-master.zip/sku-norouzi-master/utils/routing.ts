export const routing = {
    auth: {
        login: "/auth/signin",
    },
    user: {
        getAllProject: "/post?skip=1",
    },
};
