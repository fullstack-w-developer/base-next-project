import React from "react";
import SearchMobile from "../../components/SearchMobile";

const Search = () => {
    return <SearchMobile />;
};

export default Search;
